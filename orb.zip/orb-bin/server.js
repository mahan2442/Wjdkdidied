require("dotenv").config?.();
const express = require("express");
const http = require("http");
const path = require("path");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { Pool } = require("pg");
const { Server } = require("socket.io");
const { AccessToken } = require("livekit-server-sdk");

const required = ["DATABASE_URL","JWT_SECRET","SITE_OWNER_USERNAME","LIVEKIT_URL","LIVEKIT_API_KEY","LIVEKIT_API_SECRET"];
const missing = required.filter(k => !process.env[k]);
if (missing.length) {
  console.error("Missing environment variables:", missing.join(", "));
  process.exit(1);
}
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL.includes("localhost") ? false : { rejectUnauthorized: false } });
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: false } });
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));
app.use("/api/auth", rateLimit({ windowMs: 15*60*1000, limit: 30 }));
const sign = user => jwt.sign({ id:user.id, username:user.username }, process.env.JWT_SECRET, { expiresIn:"7d" });
function auth(req,res,next) {
  try {
    const token = req.cookies.orb_session || (req.headers.authorization || "").replace(/^Bearer /,"");
    if (!token) return res.status(401).json({error:"ابتدا وارد حساب شوید."});
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch { res.status(401).json({error:"نشست شما منقضی شده است."}); }
}
async function userRow(id) { const r=await pool.query("SELECT id,username,display_name FROM users WHERE id=$1",[id]); return r.rows[0]; }
async function isSiteOwner(user) { return user.username.toLowerCase() === process.env.SITE_OWNER_USERNAME.toLowerCase(); }
async function roomAccess(roomId,userId) {
  const r=await pool.query(`SELECT rm.*,u.username,u.display_name,ro.owner_id,ro.title FROM rooms ro
    JOIN room_members rm ON rm.room_id=ro.id JOIN users u ON u.id=rm.user_id
    WHERE ro.id=$1 AND rm.user_id=$2`,[roomId,userId]);
  return r.rows[0];
}
function allowed(member, key, owner=false) { return owner || member?.role==="teacher" || member?.permissions?.[key]===true; }
async function requireRoom(req,res,next) {
  try {
    const owner=await isSiteOwner(req.user);
    const member=await roomAccess(req.params.id,req.user.id);
    if (!member && !owner) return res.status(403).json({error:"شما عضو این کلاس نیستید."});
    req.member=member; req.siteOwner=owner; next();
  } catch(e){ next(e); }
}
async function init() {
  await pool.query(`CREATE TABLE IF NOT EXISTS users (
    id BIGSERIAL PRIMARY KEY, username VARCHAR(40) UNIQUE NOT NULL,
    display_name VARCHAR(80) NOT NULL, password_hash TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS rooms (
    id TEXT PRIMARY KEY, title VARCHAR(120) NOT NULL, owner_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), is_chat_open BOOLEAN NOT NULL DEFAULT TRUE, chat_mode VARCHAR(16) NOT NULL DEFAULT 'public')`);
  await pool.query(`CREATE TABLE IF NOT EXISTS room_members (
    room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE, user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role VARCHAR(16) NOT NULL DEFAULT 'student', permissions JSONB NOT NULL DEFAULT '{}'::jsonb,
    joined_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), PRIMARY KEY(room_id,user_id))`);
  await pool.query(`CREATE TABLE IF NOT EXISTS messages (
    id BIGSERIAL PRIMARY KEY, room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
    user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE, body TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(), edited_at TIMESTAMPTZ)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS polls (
    id BIGSERIAL PRIMARY KEY, room_id TEXT NOT NULL REFERENCES rooms(id) ON DELETE CASCADE,
    creator_id BIGINT NOT NULL REFERENCES users(id), question TEXT NOT NULL, options JSONB NOT NULL,
    active BOOLEAN NOT NULL DEFAULT TRUE, created_at TIMESTAMPTZ NOT NULL DEFAULT NOW())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS poll_votes (
    poll_id BIGINT NOT NULL REFERENCES polls(id) ON DELETE CASCADE, user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    option_index INTEGER NOT NULL, PRIMARY KEY(poll_id,user_id))`);
}
app.get("/api/health", (req,res)=>res.json({ok:true,service:"orb-bin"}));
app.post("/api/auth/register", async(req,res,next)=>{
  try {
    const username=String(req.body.username||"").trim().toLowerCase();
    const displayName=String(req.body.displayName||username).trim().slice(0,80);
    const password=String(req.body.password||"");
    if(!/^[a-z0-9_]{3,40}$/.test(username)) return res.status(400).json({error:"نام کاربری باید ۳ تا ۴۰ حرف انگلیسی، عدد یا _ باشد."});
    if(password.length<8) return res.status(400).json({error:"رمز عبور باید حداقل ۸ کاراکتر باشد."});
    const hash=await bcrypt.hash(password,12);
    const r=await pool.query("INSERT INTO users(username,display_name,password_hash) VALUES($1,$2,$3) RETURNING id,username,display_name",[username,displayName||username,hash]);
    const token=sign(r.rows[0]); res.cookie("orb_session",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7*864e5});
    res.status(201).json({user:r.rows[0]});
  } catch(e){ if(e.code==="23505") return res.status(409).json({error:"این نام کاربری قبلاً ثبت شده است."}); next(e); }
});
app.post("/api/auth/login",async(req,res,next)=>{
  try {
    const username=String(req.body.username||"").trim().toLowerCase();
    const r=await pool.query("SELECT * FROM users WHERE username=$1",[username]);
    if(!r.rows[0] || !(await bcrypt.compare(String(req.body.password||""),r.rows[0].password_hash))) return res.status(401).json({error:"نام کاربری یا رمز عبور اشتباه است."});
    const u=r.rows[0]; res.cookie("orb_session",sign(u),{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7*864e5});
    res.json({user:{id:u.id,username:u.username,display_name:u.display_name}});
  } catch(e){next(e);}
});
app.post("/api/auth/logout",(req,res)=>{res.clearCookie("orb_session");res.json({ok:true});});
app.get("/api/me",auth,async(req,res,next)=>{try{const u=await userRow(req.user.id);res.json({user:u,siteOwner:await isSiteOwner(req.user)});}catch(e){next(e);}});
app.get("/api/rooms",auth,async(req,res,next)=>{
  try {
    const owner=await isSiteOwner(req.user);
    const q=owner
      ? await pool.query("SELECT r.*,u.display_name AS owner_name FROM rooms r JOIN users u ON u.id=r.owner_id ORDER BY r.created_at DESC")
      : await pool.query("SELECT r.*,u.display_name AS owner_name FROM rooms r JOIN room_members m ON m.room_id=r.id JOIN users u ON u.id=r.owner_id WHERE m.user_id=$1 ORDER BY r.created_at DESC",[req.user.id]);
    res.json({rooms:q.rows});
  }catch(e){next(e);}
});
app.post("/api/rooms",auth,async(req,res,next)=>{
  try {
    const title=String(req.body.title||"").trim().slice(0,120);
    if(!title) return res.status(400).json({error:"نام کلاس را وارد کنید."});
    const id=crypto.randomUUID();
    const c=await pool.connect();
    try { await c.query("BEGIN"); await c.query("INSERT INTO rooms(id,title,owner_id) VALUES($1,$2,$3)",[id,title,req.user.id]); await c.query("INSERT INTO room_members(room_id,user_id,role,permissions) VALUES($1,$2,'teacher',$3)",[id,req.user.id,JSON.stringify({members:true,chat:true,whiteboard:true,microphone:true,camera:true,screen:true,polls:true})]); await c.query("COMMIT"); }
    catch(e){await c.query("ROLLBACK");throw e;} finally{c.release();}
    res.status(201).json({room:{id,title}});
  }catch(e){next(e);}
});
app.get("/api/rooms/:id/messages",auth,requireRoom,async(req,res,next)=>{
  try {
    const r=await pool.query(`SELECT m.id,m.room_id,m.user_id,m.body,m.created_at,m.edited_at,u.display_name,u.username
      FROM messages m JOIN users u ON u.id=m.user_id WHERE m.room_id=$1 ORDER BY m.created_at ASC LIMIT 300`,[req.params.id]);
    res.json({messages:r.rows});
  } catch(e){next(e);}
});
app.get("/api/rooms/:id",auth,requireRoom,async(req,res,next)=>{
  try {
    const r=await pool.query("SELECT id,title,owner_id,is_chat_open,chat_mode,created_at FROM rooms WHERE id=$1",[req.params.id]);
    const members=await pool.query(`SELECT u.id,u.username,u.display_name,rm.role,rm.permissions FROM room_members rm JOIN users u ON u.id=rm.user_id WHERE rm.room_id=$1 ORDER BY CASE rm.role WHEN 'teacher' THEN 0 ELSE 1 END,u.display_name`,[req.params.id]);
    const owner=await isSiteOwner(req.user);
    const me=members.rows.find(x=>String(x.id)===String(req.user.id));
    res.json({room:r.rows[0],members:members.rows,me,siteOwner:owner});
  }catch(e){next(e);}
});
app.post("/api/rooms/:id/join",auth,requireRoom,async(req,res,next)=>{
  try {
    const owner=await isSiteOwner(req.user);
    const room=(await pool.query("SELECT id,title FROM rooms WHERE id=$1",[req.params.id])).rows[0];
    const member=req.member || {role:"owner",permissions:{}};
    const identity=String(req.user.id);
    const at=new AccessToken(process.env.LIVEKIT_API_KEY,process.env.LIVEKIT_API_SECRET,{identity,name:(await userRow(req.user.id)).display_name,ttl:"2h"});
    at.addGrant({roomJoin:true,room:req.params.id,canPublish:owner||allowed(member,"microphone")||allowed(member,"camera")||allowed(member,"screen"),canSubscribe:true});
    res.json({token:await at.toJwt(),serverUrl:process.env.LIVEKIT_URL,room});
  }catch(e){next(e);}
});
app.patch("/api/rooms/:id/members/:userId",auth,requireRoom,async(req,res,next)=>{
  try {
    if(!(req.siteOwner || req.member?.role==="teacher")) return res.status(403).json({error:"اجازه مدیریت اعضا را ندارید."});
    const target=await roomAccess(req.params.id,req.params.userId);
    if(!target) return res.status(404).json({error:"عضو پیدا نشد."});
    if(target.role==="teacher" && !req.siteOwner) return res.status(403).json({error:"فقط سازنده سایت می‌تواند مجوز معلم را تغییر دهد."});
    const permissions=req.body.permissions;
    const role=req.body.role;
    const keys=["members","chat","whiteboard","microphone","camera","screen","polls"];
    if(permissions && (typeof permissions!=="object" || Object.keys(permissions).some(k=>!keys.includes(k)))) return res.status(400).json({error:"مجوز نامعتبر است."});
    await pool.query("UPDATE room_members SET permissions=COALESCE($3,permissions),role=COALESCE($4,role) WHERE room_id=$1 AND user_id=$2",[req.params.id,req.params.userId,permissions||null,role||null]);
    io.to(req.params.id).emit("members:refresh");
    res.json({ok:true});
  }catch(e){next(e);}
});
app.delete("/api/rooms/:id/members/:userId",auth,requireRoom,async(req,res,next)=>{
  try {
    if(!(req.siteOwner||req.member?.role==="teacher")) return res.status(403).json({error:"اجازه اخراج عضو را ندارید."});
    if(String(req.params.userId)===String(req.user.id)) return res.status(400).json({error:"نمی‌توانید خودتان را اخراج کنید."});
    await pool.query("DELETE FROM room_members WHERE room_id=$1 AND user_id=$2",[req.params.id,req.params.userId]);
    io.to(req.params.id).emit("members:refresh");
    res.json({ok:true});
  }catch(e){next(e);}
});
app.patch("/api/rooms/:id/chat",auth,requireRoom,async(req,res,next)=>{
  try {
    if(!(req.siteOwner||req.member?.role==="teacher")) return res.status(403).json({error:"فقط معلم یا مالک می‌تواند تنظیمات چت را تغییر دهد."});
    const {isOpen,mode}=req.body;
    if(typeof isOpen==="boolean") await pool.query("UPDATE rooms SET is_chat_open=$2 WHERE id=$1",[req.params.id,isOpen]);
    if(["public","private"].includes(mode)) await pool.query("UPDATE rooms SET chat_mode=$2 WHERE id=$1",[req.params.id,mode]);
    io.to(req.params.id).emit("chat:settings",{isOpen,mode});res.json({ok:true});
  }catch(e){next(e);}
});
app.delete("/api/rooms/:id/messages",auth,requireRoom,async(req,res,next)=>{
  try { if(!(req.siteOwner||req.member?.role==="teacher")) return res.status(403).json({error:"اجازه حذف همه پیام‌ها را ندارید."}); await pool.query("DELETE FROM messages WHERE room_id=$1",[req.params.id]); io.to(req.params.id).emit("chat:clear");res.json({ok:true}); }catch(e){next(e);}
});
app.patch("/api/messages/:messageId",auth,async(req,res,next)=>{
  try {const body=String(req.body.body||"").trim().slice(0,2000);const r=await pool.query("UPDATE messages SET body=$2,edited_at=NOW() WHERE id=$1 AND user_id=$3 RETURNING *",[req.params.messageId,body,req.user.id]);if(!r.rows[0])return res.status(404).json({error:"پیام پیدا نشد یا متعلق به شما نیست."});io.to(r.rows[0].room_id).emit("chat:edited",r.rows[0]);res.json({message:r.rows[0]});}catch(e){next(e);}
});
app.delete("/api/messages/:messageId",auth,async(req,res,next)=>{
  try {const r=await pool.query("SELECT m.*,ro.id AS rid FROM messages m JOIN rooms ro ON ro.id=m.room_id WHERE m.id=$1",[req.params.messageId]);if(!r.rows[0])return res.status(404).json({error:"پیام پیدا نشد."});const member=await roomAccess(r.rows[0].room_id,req.user.id);const owner=await isSiteOwner(req.user);if(String(r.rows[0].user_id)!==String(req.user.id)&&!(owner||member?.role==="teacher"))return res.status(403).json({error:"اجازه حذف این پیام را ندارید."});await pool.query("DELETE FROM messages WHERE id=$1",[req.params.messageId]);io.to(r.rows[0].room_id).emit("chat:deleted",{id:Number(req.params.messageId)});res.json({ok:true});}catch(e){next(e);}
});
app.post("/api/rooms/:id/polls",auth,requireRoom,async(req,res,next)=>{
  try {if(!(req.siteOwner||req.member?.role==="teacher"||allowed(req.member,"polls")))return res.status(403).json({error:"اجازه ساخت نظرسنجی ندارید."});const question=String(req.body.question||"").trim().slice(0,300);const options=(req.body.options||[]).map(x=>String(x).trim().slice(0,120)).filter(Boolean).slice(0,8);if(!question||options.length<2)return res.status(400).json({error:"سؤال و حداقل دو گزینه لازم است."});const r=await pool.query("INSERT INTO polls(room_id,creator_id,question,options) VALUES($1,$2,$3,$4) RETURNING *",[req.params.id,req.user.id,question,JSON.stringify(options)]);io.to(req.params.id).emit("poll:new",r.rows[0]);res.status(201).json({poll:r.rows[0]});}catch(e){next(e);}
});
app.post("/api/polls/:id/vote",auth,async(req,res,next)=>{
  try {const p=(await pool.query("SELECT * FROM polls WHERE id=$1 AND active=true",[req.params.id])).rows[0];if(!p)return res.status(404).json({error:"نظرسنجی فعال پیدا نشد."});const index=Number(req.body.optionIndex);if(!Number.isInteger(index)||index<0||index>=p.options.length)return res.status(400).json({error:"گزینه نامعتبر است."});await pool.query("INSERT INTO poll_votes(poll_id,user_id,option_index) VALUES($1,$2,$3) ON CONFLICT(poll_id,user_id) DO UPDATE SET option_index=EXCLUDED.option_index",[p.id,req.user.id,index]);const votes=await pool.query("SELECT option_index,COUNT(*)::int AS count FROM poll_votes WHERE poll_id=$1 GROUP BY option_index",[p.id]);const counts=p.options.map((_,i)=>votes.rows.find(x=>x.option_index===i)?.count||0);io.to(p.room_id).emit("poll:results",{id:p.id,counts,total:counts.reduce((a,b)=>a+b,0)});res.json({counts,total:counts.reduce((a,b)=>a+b,0)});}catch(e){next(e);}
});
io.use(async(socket,next)=>{
  try {const cookieHeader=socket.handshake.headers.cookie||"";
    const match=cookieHeader.match(/(?:^|;\\s*)orb_session=([^;]+)/);
    const token=socket.handshake.auth?.token || (match ? decodeURIComponent(match[1]) : null);
    const payload=jwt.verify(token,process.env.JWT_SECRET);socket.user=payload;next();}catch{next(new Error("احراز هویت ناموفق"));}
});
io.on("connection",socket=>{
  socket.on("room:join",async({roomId},cb)=>{
    try {const owner=await isSiteOwner(socket.user);const m=await roomAccess(roomId,socket.user.id);if(!m&&!owner)return cb?.({error:"عضو کلاس نیستید."});socket.join(roomId);cb?.({ok:true});}catch(e){cb?.({error:"خطای ورود به کلاس"});}
  });
  socket.on("chat:send",async({roomId,body},cb)=>{
    try {const m=await roomAccess(roomId,socket.user.id);const owner=await isSiteOwner(socket.user);if(!m&&!owner)return cb?.({error:"دسترسی ندارید"});const text=String(body||"").trim().slice(0,2000);if(!text)return cb?.({error:"پیام خالی است"});const settings=(await pool.query("SELECT is_chat_open,chat_mode FROM rooms WHERE id=$1",[roomId])).rows[0];if(!settings?.is_chat_open)return cb?.({error:"چت بسته است"});const u=await userRow(socket.user.id);const r=await pool.query("INSERT INTO messages(room_id,user_id,body) VALUES($1,$2,$3) RETURNING *",[roomId,socket.user.id,text]);const msg={...r.rows[0],display_name:u.display_name,username:u.username};io.to(roomId).emit("chat:message",msg);cb?.({ok:true});}catch(e){cb?.({error:"ارسال پیام ناموفق بود"});}
  });
  socket.on("whiteboard:draw",async({roomId,action})=>{const m=await roomAccess(roomId,socket.user.id);if(m&&(m.role==="teacher"||m.permissions?.whiteboard===true))socket.to(roomId).emit("whiteboard:draw",action);});
  socket.on("hand:raise",async({roomId,raised})=>{const u=await userRow(socket.user.id);socket.to(roomId).emit("hand:update",{userId:socket.user.id,displayName:u?.display_name,raised:!!raised});});
});
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"خطای داخلی سرور. لاگ سرور را بررسی کنید."});});
init().then(()=>server.listen(process.env.PORT||3000,"0.0.0.0",()=>console.log("ORB BIN listening"))).catch(e=>{console.error("Database initialization failed",e);process.exit(1);});
